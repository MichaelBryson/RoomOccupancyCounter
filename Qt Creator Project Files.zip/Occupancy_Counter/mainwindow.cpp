#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "sensordebug.h"
#include <QSerialPort>
#include <QSerialPortInfo>
//#include <QDebug>
#include <QtWidgets>
#include <QString>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <QSlider>
#include <QScrollBar>
#include <QtMath>
#include <QKeyEvent>

// ----------------------------------------------------------------------------------
// CONSTRUCTOR
// ----------------------------------------------------------------------------------
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // ----------------------------------------------------------------------------------
    // SET THE APPLICATION NAME, WINDOW TITLE, AND WINDOW SIZE
    // ----------------------------------------------------------------------------------
    {
    QCoreApplication::setApplicationName("Bidirectional Room Occupancy Counter");
    setWindowTitle("Bidirectional Room Occupancy Counter"); //Set title for main window
    resize(QDesktopWidget().availableGeometry(this).size() * 0.7);
    }


    // ----------------------------------------------------------------------------------
    // SETUP THE SERIAL PORT FOR THE ARDUINO UNO
    // ----------------------------------------------------------------------------------
    {
    //Determine the vendor and product ID for the Arduino
    /*
    qDebug() << "Number of available ports: " << QSerialPortInfo::availablePorts().length();
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        qDebug() << "Has vendor ID: " << serialPortInfo.hasVendorIdentifier();
        if(serialPortInfo.hasVendorIdentifier())
        {
            qDebug() << "Vendor ID: " << serialPortInfo.vendorIdentifier();
        }
        qDebug() << "Has product ID: " << serialPortInfo.hasProductIdentifier();
        if(serialPortInfo.hasProductIdentifier())
        {
            qDebug() << "Vendor ID: " << serialPortInfo.productIdentifier();
        }
    }*/

    //Initialize Port Variables
    arduino_port_name = "";
    arduino = new QSerialPort;
    serialBuffer = "";
    arduino_is_available = false;

    // Check the serial ports for the Arduino Uno
    checkPorts();

    //Configure the serial port (connect to the Arduino)
    connectDevice();

    //Setup the timer to check if the arduino is still connected
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(checkConnection()));
    timer->start(50);   //Timer will timeout every 50 ms
    }


    // ----------------------------------------------------------------------------------
    // SETUP THE GRAPHS
    // ----------------------------------------------------------------------------------
    {
        //Setup the Graph1
        ui->plot->addGraph(); //Add the graph
        ui->plot->graph(0)->setScatterStyle(QCPScatterStyle::ssDisc); //Set the style for the data points
        ui->plot->graph(0)->setLineStyle(QCPGraph::lsLine); //Set the line style for the plot
        ui->plot->yAxis->setRange(0.01, 1024.0); //Set the default y-axis plot range

        //Setup the Graph Axes to display time
        QSharedPointer<QCPAxisTickerTime> timeTicker(new QCPAxisTickerTime);
        timeTicker->setTimeFormat("%m:%s"); //Axis labels display in second (?) precision
        ui->plot->xAxis->setTicker(timeTicker);
        ui->plot->xAxis->setRange(0,10);   //Set the scale for the x-axis

        connect(ui->plot->xAxis, SIGNAL(rangeChanged(QCPRange)), ui->plot->xAxis2, SLOT(setRange(QCPRange)));
        connect(ui->plot->yAxis, SIGNAL(rangeChanged(QCPRange)), ui->plot->yAxis2, SLOT(setRange(QCPRange)));

        //Setup the Graph2
        ui->plot2->addGraph(); //Add the graph
        ui->plot2->graph(0)->setScatterStyle(QCPScatterStyle::ssDisc); //Set the style for the data points
        ui->plot2->graph(0)->setLineStyle(QCPGraph::lsLine); //Set the line style for the plot
        ui->plot2->yAxis->setRange(0.01, 1024.0); //Set the default y-axis plot range

        //Setup the Graph Axes to display time
        QSharedPointer<QCPAxisTickerTime> timeTicker2(new QCPAxisTickerTime);
        timeTicker2->setTimeFormat("%m:%s"); //Axis labels display in second (?) precision
        ui->plot2->xAxis->setTicker(timeTicker2);
        ui->plot2->xAxis->setRange(0,10);   //Set the scale for the x-axis

        connect(ui->plot2->xAxis, SIGNAL(rangeChanged(QCPRange)), ui->plot2->xAxis2, SLOT(setRange(QCPRange)));
        connect(ui->plot2->yAxis, SIGNAL(rangeChanged(QCPRange)), ui->plot2->yAxis2, SLOT(setRange(QCPRange)));
    }


    // ----------------------------------------------------------------------------------
    // SETUP THE SLIDER AND SCROLLBAR
    // ----------------------------------------------------------------------------------
    {
    ui->slider->setRange(0,slideMax);
    ui->slider->setValue(slideMax/2);
    ui->scrollBar->setMinimum(scrollMin);
    ui->scrollBar->setMaximum(scrollMax);
    }

}

// ----------------------------------------------------------------------------------
// DESTRUCTOR
// ----------------------------------------------------------------------------------
MainWindow::~MainWindow()
{
    if(arduino->isOpen())
    {
        arduino->close();
    }

    delete ui;
}

// ----------------------------------------------------------------------------------
// BUTTONS
// ----------------------------------------------------------------------------------

//This function toggles the functionality of the record button
//and sets a variable to specify if the user has clicked record.
void MainWindow::on_btn_record_clicked()
{
    //Stop recording
    if (recording)
    {
        ui->btn_record->setText("Record");
        recording = false;
        badData = true;
        timeMax = timecode.last();              //Access the last time element
        alignTime = timeMax;
        on_slider_valueChanged(slideValue);     //Call the slider function to set the scrollbar size
    }

    //Start recording
    else
    {
        //If there is still data in the queue, inform the user to save/clear it before recording
        if (existingData)
        {
            QMessageBox::warning(this,"Warning","Data must be cleared before recording.");
        }

        //If the device is in troubleshoot mode, warn the user and allow them to open the troubleshoot tool
        else if (troubleshootMode)
        {
            QMessageBox msgBox;
            msgBox.setIcon(QMessageBox::Warning);
            msgBox.setWindowTitle("Troubleshooting Mode");
            msgBox.setText("The device is currently in troubleshooting mode and normal recording is disabled.");
            msgBox.setInformativeText("Do you want to open the troubleshooting tool?");
            QPushButton *yesBtn = msgBox.addButton(QMessageBox::Yes);
            msgBox.addButton(QMessageBox::No);
            msgBox.setDefaultButton(yesBtn);
            msgBox.exec();

            //If the YES button is pressed, the troubleshooting tool will open
            if (msgBox.clickedButton() == yesBtn)
            {
                //Troubleshooting tool will open
                on_actionTroubleshoot_triggered();
            }
            //If the NO button is pressed or if the message is closed, nothing will happen
        }

        //Otherwise, check the connection and start recording
        else
        {
            checkPorts();
            connectDevice();

            //If the arduino is connected, start recording
            if(arduinoConnected)
            {
                if(dataAvailable)
                {
                    ui->btn_record->setText("Stop");
                    recording = true;
                    scrollMax = 0;
                    ui->scrollBar->setMaximum(scrollMax);   //Disable the scrollBar
                    slideValue = slideMax/2;
                    dataSaved = false;                      //Mark that data has not been saved
                }
                else
                {
                    QMessageBox::warning(this,"Setup Incomplete","Please complete the device setup before recording.");
                }
            }

            //Otherwise, inform the user that the device is not connected
            else
            {
                arduinoMissing();
            }
        }
    }
}

//This function handles the save functionality of opening a save dialog
//and saving the data from the lists into a text file specified by the user.
void MainWindow::on_btn_save_clicked()
{
    if (timecodeStr.isEmpty())
    {
        QMessageBox::information(this,"No Data","There is no data to save.");
    }
    else
    {
        if(recording != true)
        {
            QString filter = "Text File (*.txt)";
            QString filename = QFileDialog::getSaveFileName(this,"Save","C://",filter);
            QFile file(filename);
            if(file.open(QFile::WriteOnly | QFile::Text))
            {
                QTextStream out(&file);
                out << "Time       \tSensor_1\tThreshold_1\tSensor_2\tThreshold_2\tCounter\n";
                for(int i=0;i<timecodeStr.size(); i++)
                {
                    out << timecodeStr.at(i);
                    out << "\t\t";
                    out << sensor1.at(i);
                    out << "\t\t";
                    out << threshold1.at(i);
                    out << "\t\t";
                    out << sensor2.at(i);
                    out << "\t\t";
                    out << threshold2.at(i);
                    out << "\t\t";
                    out << counter.at(i);
                    out << "\n";
                }

                file.flush();
                file.close();
                dataSaved = true;
            }
        }
        else
        {
            QMessageBox::warning(this,"Warning","Data cannot be saved during recording.");
        }
    }
}

//This function clears the data in the queues and lists
void MainWindow::on_btn_clear_clicked()
{
    if (timecodeStr.isEmpty())
    {
        QMessageBox::information(this,"No Data","There is no data to clear.");
    }
    else
    {
        if(!recording)      //If recording has been stopped
        {
            if(dataSaved)   //If the data has already been saved, the data will be cleared
            {
                clearData();
            }
            else            //If the data has not been saved, a warning will be displayed
            {
                QMessageBox msgBox;
                msgBox.setIcon(QMessageBox::Warning);
                msgBox.setWindowTitle("Warning");
                msgBox.setText("The data will be lost if you clear it.");
                msgBox.setInformativeText("Do you want to save the data first?");
                QPushButton *saveBtn = msgBox.addButton(QMessageBox::Save);
                QPushButton *clearBtn = msgBox.addButton(tr("Clear"),QMessageBox::ActionRole);
                QPushButton *cancelBtn = msgBox.addButton(QMessageBox::Cancel);
                msgBox.setDefaultButton(clearBtn);
                msgBox.exec();

                if (msgBox.clickedButton() == saveBtn)
                {
                    //Data will be saved and then cleared
                    on_btn_save_clicked();
                    if(dataSaved)
                    {
                        clearData();
                    }
                }
                else if(msgBox.clickedButton() == clearBtn) //Data will be cleared and the displays updated
                {
                    clearData();
                }
                else if(msgBox.clickedButton() == cancelBtn){}   //Message will close and nothing will happen
            }
        }
        else
        {
            QMessageBox::warning(this,"Warning","Data cannot be cleared during recording.");
        }
    }
}

//This function reads a value from the slider and uses it to set the plot width
void MainWindow::on_slider_valueChanged(int value)
{
    if(recording || existingData)
    {
        //Calculate the plotWidth
        //----------------------------------------------------------------------
        slideValue = value;                     //Save the slider value
        value = -value + slideMax;              //Invert the range
        double slideMaxD = slideMax;            //Create a double of slideMax
        double b = qPow(10,2/slideMaxD);        //Calculate the exponent base b
        plotWidth = qPow(b,value);              //Calculate plotWidth
        int setScroll;                          //Variable to specify which case occurred

        if(!recording)  //If it is not recording, replot the graphs
        {
            //If the data is smaller than the plot window,
            //or the alignTime is left of the plot center,
            //align left at t=0
            if(timeMax < pwMultiplier*plotWidth || alignTime < plotWidth/2)
            {
                alignPoint = 0;
                ui->plot->xAxis->setRange(alignPoint,plotWidth,Qt::AlignLeft); //Realign the plot
                ui->plot->replot();
                ui->plot2->xAxis->setRange(alignPoint,plotWidth,Qt::AlignLeft); //Realign the plot
                ui->plot2->replot();
                setScroll = 0;
            }
            //If the time difference between the alignTime and the timeMax
            //is less than half the plot area, align right at the right data edge
            else if((timeMax - alignTime) < (pwMultiplier - 0.5)*plotWidth)
            {
                alignPoint = timeMax + (1-pwMultiplier)*plotWidth;
                ui->plot->xAxis->setRange(alignPoint,plotWidth,Qt::AlignRight); //Realign the plot
                ui->plot->replot();
                ui->plot2->xAxis->setRange(alignPoint,plotWidth,Qt::AlignRight); //Realign the plot
                ui->plot2->replot();
                setScroll = 1;
            }
            //If the alignTime is within the plot window and
            //the time range is greater than the plot window, align center
            else
            {
                alignPoint = alignTime;
                ui->plot->xAxis->setRange(alignPoint,plotWidth,Qt::AlignCenter); //Realign the plot
                ui->plot->replot();
                ui->plot2->xAxis->setRange(alignPoint,plotWidth,Qt::AlignCenter); //Realign the plot
                ui->plot2->replot();
                setScroll = 2;
            }

            //Calculate new scrollMax
            //--------------------------------
            int valueLimit = qCeil(log_b(b,timeMax/pwMultiplier));  //Calculate the lower limit for scrolling
            valueLimit = -valueLimit + slideMax;                    //Invert the valueLimit to match the inverted value
            value = -value + slideMax;                              //Invert the range back
            int scrollMaxNew = 2*(value-valueLimit);                //Calculate new scrollMax
            if(scrollMaxNew <= 0)                                   //Guarantee scrollMaxNew is >= 0
            {
                scrollMaxNew = 0;
            }

            //Calculate new scrollBarValue
            //---------------------------------
            double timeRange = timeMax - pwMultiplier*plotWidth;  //Calculate the time range for scrolling

            //If the plot was aligned left, set the scrollBarValue to zero
            if(setScroll == 0)
            {
                scrollBarPosition = 0;
            }
            //If the plot was aligned right, set the scrollBarValue to max
            else if(setScroll == 1)
            {
                scrollBarPosition = 1;
            }
            //If the plot was aligned center, set the scrollBarVallue to the appropriate fractional position
            else if(setScroll == 2)
            {
                scrollBarPosition = (alignTime - plotWidth/2)/timeRange;
            }

            //Set the scrollBar values
            scrollMax = scrollMaxNew;
            scrollBarValue = double2int(scrollBarPosition*scrollMaxNew);

            //Set the scrollBar
            scrollEnabled = false;
            ui->scrollBar->setMaximum(scrollMax);   //Set the new scrollBar maximum
            ui->scrollBar->setValue(scrollBarValue);//Set the new scrollBar value
            scrollEnabled = true;
        }
    }
    else
    {
        ui->slider->setValue(slideMax/2);
    }
}

//This function allows the user to scroll the graphs when not recording
void MainWindow::on_scrollBar_valueChanged(int value)
{
    //Enable the scroll bar if the maximum is not zero
    if(scrollMax != 0 && scrollEnabled)
    {
        double valueDouble = value;                 //Convert value to a double
        scrollBarPosition = valueDouble/scrollMax;  //Fractional scrollBar position (range: 0 to 1)
        scrollBarValue = value;                     //Save the current scrollBar value
        //scrollMaxPrev = scrollMax;                  //Save the previous scrollMax

        double timeRange = timeMax - pwMultiplier*plotWidth;    //This is the range of times that can be selected as the alignPoint
        alignPoint = scrollBarPosition * timeRange;             //Calculate the left align point
        alignTime = alignPoint + plotWidth/2;                   //Calculate the time corresponding to the graph center
        ui->plot->xAxis->setRange(alignPoint,plotWidth,Qt::AlignLeft); //Realign the plot
        ui->plot->replot();
        ui->plot2->xAxis->setRange(alignPoint,plotWidth,Qt::AlignLeft); //Realign the plot
        ui->plot2->replot();
    }
}

//This function decreases the zoom slider by 2
void MainWindow::on_btn_zoomOUT_clicked()
{
    slideValue = slideValue - 1;   //Decrease the slider value (zoom out)
    if(slideValue < 0)
    {
        slideValue = 0;
    }
    ui->slider->setValue(slideValue);
}

//This function increases the zoom slider by 2
void MainWindow::on_btn_zoomIN_clicked()
{
    slideValue = slideValue + 1;   //Increase the slider value (zoom in)
    if(slideValue > slideMax)
    {
        slideValue = slideMax;
    }
    ui->slider->setValue(slideValue);
}

//This function moves the scrollBar left
void MainWindow::scrollLeft()
{
    if(scrollBarValue > 0)
    {
        scrollBarValue--;
        ui->scrollBar->setValue(scrollBarValue);//Set the new scrollBar value
    }
}

//This function moves the scrollBar right
void MainWindow::scrollRight()
{
    if(scrollBarValue < scrollMax)
    {
        scrollBarValue++;
        ui->scrollBar->setValue(scrollBarValue);//Set the new scrollBar value
    }
}

//This function calls the record button function
void MainWindow::on_actionRecord_triggered()
{
    on_btn_record_clicked();
}

//This function calls the save button function
void MainWindow::on_actionSave_triggered()
{
    on_btn_save_clicked();
}

//This function calls the clear button function
void MainWindow::on_actionClear_triggered()
{
    on_btn_clear_clicked();
}

//This function generates a QMessageBox that displays
//a message about the project and the software
void MainWindow::on_actionAbout_triggered()
{
    QMessageBox msgBox;
    QPixmap icon(":/Icons/Icons/Application_Logo.ico");
    QPixmap appIcon;
    int width = 80;
    int height = width;
    appIcon = icon.scaled(width,height,Qt::KeepAspectRatio,Qt::SmoothTransformation);
    msgBox.setIconPixmap(appIcon);
    msgBox.setWindowTitle("About");
    msgBox.setText("<b><big><big>Bidirectional Room<br/>Occupancy Counter</big></big></b><br/>"
                   "<i>Version 2.0</i><br/>"
                   "Released: 9/20/2019<br/><br/>"
                   "<b>Andrews University</b><br/>"
                   "Engineering Senior Design Project 2019<br/><br/>"
                   "<b>Device designed by</b><br/>"
                   "Michael Bryson and Donavan Greenley<br/><br/>"
                   "<b>Software written by</b><br/>"
                   "Michael Bryson<br/><br/>"
                   "This program was developed to accompany the Andrews University engineering senior design project "
                   "&ldquo;Bidirectional Room Occupancy Counter&rdquo;. The purpose of the project was to design and prototype "
                   "a device that can control room lights by counting people as they enter and exit a room. "
                   "The system then keeps the lights on as long as the room is occupied. "
                   "The counter design was implemented using lasers, a reflector, and light sensors. "
                   "This program acts as a desktop interface to display the sensor and counter values, "
                   "as well as a way to troubleshoot the sensors. The original version of this program "
                   "was written during the project development and then refined into this version after "
                   "the project was complete.");
    msgBox.exec();
}

//This function displays a message box listing all the keyboard shortcuts
void MainWindow::on_actionKeyboard_Shortcuts_List_triggered()
{
    QMessageBox::information(this,"Keyboard Shortcuts","Save\t\t\tCtrl+S\n"
                                                       "Clear\t\t\tDelete\n"
                                                       "Record\t\t\tR or Space\n\n"
                                                       "Zoom In\t\tUp Arrow\n"
                                                       "Zoom Out\t\tDown Arrow\n"
                                                       "Scroll Left\t\tLeft Arrow\n"
                                                       "Scroll Right\t\tRight Arrow\n\n"
                                                       "About\t\t\tShift+A\n"
                                                       "Troubleshoot Sensors\tCtrl+T\n"
                                                       "Keyboard Shortcuts\tCtrl+K");
}

//This function opens the quick start guide pdf
void MainWindow::on_actionQuick_Start_Guide_triggered()
{
    QString applicationPath = QCoreApplication::applicationDirPath();
    bool fileOpened = QDesktopServices::openUrl(QUrl::fromLocalFile(applicationPath + "/documents/Quick_Start_Guide_ver2.0.pdf"));
    if(!fileOpened)
    {
        QMessageBox::warning(this,"File Error","This file was not found. Make sure the file Quick_Start_Guide_ver2.0.pdf is stored in the documents folder of the program root directory.");
    }
}

//This function opens the user manual pdf
void MainWindow::on_actionUser_Manual_triggered()
{
    QString applicationPath = QCoreApplication::applicationDirPath();
    bool fileOpened = QDesktopServices::openUrl(QUrl::fromLocalFile(applicationPath + "/documents/User_Manual_ver2.0.pdf"));
    if(!fileOpened)
    {
        QMessageBox::warning(this,"File Error","This file was not found. Make sure the file User_Manual_ver2.0.pdf is stored in the documents folder of the program root directory.");
    }
}

//This function opens the project report pdf
void MainWindow::on_actionProject_Report_triggered()
{
    QString applicationPath = QCoreApplication::applicationDirPath();
    bool fileOpened = QDesktopServices::openUrl(QUrl::fromLocalFile(applicationPath + "/documents/Senior_Design_Final_Project_Report.pdf"));
    if(!fileOpened)
    {
        QMessageBox::warning(this,"File Error","This file was not found. Make sure the file Senior_Design_Final_Project_Report.pdf is stored in the documents folder of the program root directory.");
    }
}

//This function opens the revision notes pdf
void MainWindow::on_actionRevision_Notes_triggered()
{
    QString applicationPath = QCoreApplication::applicationDirPath();
    bool fileOpened = QDesktopServices::openUrl(QUrl::fromLocalFile(applicationPath + "/documents/Occupancy_Counter_Revision_Notes_ver2.0.pdf"));
    if(!fileOpened)
    {
        QMessageBox::warning(this,"File Error","This file was not found. Make sure the file Occupancy_Counter_Revision_Notes_ver2.0.pdf is stored in the documents folder of the program root directory.");
    }
}

//This function opens a dialog to display the sensor values for troubleshooting
void MainWindow::on_actionTroubleshoot_triggered()
{
    //Stop recording if necessary
    if(recording)
    {
        on_btn_record_clicked();
    }

    //Close the arduino if it is open
    if(arduino->isOpen())
    {
        arduino->close();
    }

    //Open the sensor debug dialog window
    hide();
    troubleshootingOpen = true;
    sensorDebug sensor_debug;
    sensor_debug.setModal(true);
    sensor_debug.exec();
    show();
    troubleshootingOpen = false;
    newConnection = true;
    arduinoConnected = false;
    if(arduino->isOpen())
    {
        arduino->close();
    }
}

//This function handles any key presses for the purpose of shortcuts
//In order to use the arrow keys, I had to turn off the focus for the slider and scrollBar
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Up)
    {
        on_btn_zoomIN_clicked();
    }
    else if(event->key() == Qt::Key_Down)
    {
        on_btn_zoomOUT_clicked();
    }
    else if(event->key() == Qt::Key_Left)
    {
        scrollLeft();
    }
    else if(event->key() == Qt::Key_Right)
    {
        scrollRight();
    }
    else if(event->key() == Qt::Key_Space)
    {
        on_btn_record_clicked();
    }
}



// ----------------------------------------------------------------------------------
// SERIAL DATA COLLECTION
// ----------------------------------------------------------------------------------

//This function collects the serial data from the arduino and displays the data
void MainWindow::readSerial()
{
    //If the device mode has not been verified,
    //check to see if the device is in normal or troubleshooting mode
    if(!normalModeVerified)
    {
        //Collect Data
        QStringList bufferSplit1 = serialBuffer.split("\n"); //Split the data from the "junk" string
        if(bufferSplit1.length() < 3)
        {
            //Read data from the Arduino and store it in the serialBuffer
            serialData = arduino->readAll();                                    //Read Serial Data
            serialBuffer += QString::fromStdString(serialData.toStdString());   //Store Serial Data
        }
        else
        {
            //Ignore the first set of values that are read from the Arduino
            //Mark that badData is now false and reset the serialBuffer
            if(badData)
            {
                badData = false;
                serialBuffer = "";
            }
            else
            {
                //Extract the sensor data from the string
                QStringList bufferSplit2 = bufferSplit1[1].split(",");  //Split the values from the two sensors
                QString strNum5 = bufferSplit2[4];                      //Extract the counter value

                int activationCode = strNum5.toInt();                   //Convert to an int
                serialBuffer = "";                                      //Reset the serialBuffer

                //Evaluate device mode
                //----------------------
                //qDebug() << "Num from Arduino" << num2;

                //Normal Device Mode
                if(activationCode >= 0)
                {
                    normalModeVerified = true;
                }

                //Troubleshooting Device Mode
                else
                {
                    //The device is preparing to send troubleshoot data
                    if(activationCode == -1)
                    {
                        troubleshootEnabled = true;             //Enable troubleshoot auto open
                    }
                    //The device is currently sending troubleshoot data
                    else if(activationCode == -2)
                    {
                        troubleshootMode = true;                //Enable troubleshoot mode
                        if(troubleshootEnabled)                 //If auto open is enabled, open the TS tool
                        {
                            on_actionTroubleshoot_triggered();  //Auto open the troubleshoot tool
                            troubleshootEnabled = false;        //Disable troubleshoot auto open
                            troubleshootMode = false;           //Temporarily disable troubleshoot mode
                        }
                    }
                    //The device has finished sending troubleshoot data
                    else if(activationCode == -3)
                    {
                        troubleshootMode = false;
                        badData = true;
                    }
                }
            }
        }
    }
    //If normal mode has been verified, proceed as normal
    else
    {
        dataAvailable = true;
        if(recording) //If the record button has been pressed, read values from the Arduino
        {
            QStringList bufferSplit1 = serialBuffer.split("\n"); //Split the data from the "junk" string
            if(bufferSplit1.length() < 3)
            {
                //Read data from the Arduino and store it in the serialBuffer
                serialData = arduino->readAll();                                    //Read Serial Data
                serialBuffer += QString::fromStdString(serialData.toStdString());   //Store Serial Data
            }
            else
            {
                //Ignore the first set of values that are read from the Arduino
                //Mark that badData is now false and reset the serialBuffer
                if(badData)
                {
                    badData = false;
                    serialBuffer = "";
                }

                else
                {
                    //Extract the sensor data from the string
                    QStringList bufferSplit2 = bufferSplit1[1].split(","); //Split the values from the two sensors
                    QString strNum1 = bufferSplit2[0]; //Extract the value from sensor 1
                    QString strNum2 = bufferSplit2[1]; //Extract the value from sensor 2
                    QString strNum3 = bufferSplit2[2]; //Extract the value from threshold 1
                    QString strNum4 = bufferSplit2[3]; //Extract the value from threshold 2
                    QString strNum5 = bufferSplit2[4]; //Extract the counter value

                    //Convert the sensor value strings to integers for graphing
                    int num1 = strNum1.toInt();
                    int num2 = strNum2.toInt();

                    //Get the time elapsed since recording started
                    double currentTime = getCurrentTime();

                    //Add the data to the appropriate queues and lists
                    timecode.enqueue(currentTime);
                    timecodeStr.append(QString::number(currentTime,'f',3));
                    sensor1.append(strNum1);
                    sensor2.append(strNum2);
                    threshold1.append(strNum3);
                    threshold2.append(strNum4);
                    counter.append(strNum5);

                    if(recording)
                    {
                        if(sensor1.isEmpty() != true)
                        {
                            existingData = true;
                        }
                    }

                    //Display the data
                    addPoints(currentTime,num1,currentTime,num2);
                    plot(currentTime);
                    updateLCD(strNum1,strNum2,strNum3,strNum4,strNum5);
                    serialBuffer = ""; //Reset the serialBuffer
                }
            }
        }
    }
}


// ----------------------------------------------------------------------------------
// PLOTTING AND DISPLAYS
// ----------------------------------------------------------------------------------

//This function adds the points to be plotted
void MainWindow::addPoints(double x1, double y1, double x2, double y2)
{
    qv_x1.append(x1);
    qv_y1.append(y1);

    qv_x2.append(x2);
    qv_y2.append(y2);
}

//This function plots the current points on the graphs
//while also recentering it to keep the present point
//in the center of the graph.
void MainWindow::plot(double currentTime)
{
    if(currentTime < pwMultiplier*plotWidth)
    {
        alignPoint = 0; //New graph edge
    }
    else
    {
        alignPoint = currentTime - (pwMultiplier*plotWidth); //New graph edge
    }
    alignTime = currentTime;    //The current point in time that is being aligned (will change after recording)

    ui->plot->graph(0)->setData(qv_x1, qv_y1); //Set the data to be plotted
    ui->plot->xAxis->setRange(alignPoint,plotWidth,Qt::AlignLeft); //Realign the plot
    ui->plot->replot(); //Plot the data
    ui->plot->update();

    ui->plot2->graph(0)->setData(qv_x2, qv_y2); //Set the data to be plotted
    ui->plot2->xAxis->setRange(alignPoint,plotWidth,Qt::AlignLeft); //Realign the plot
    ui->plot2->replot(); //Plot the data
    ui->plot2->update();
}

//This function clears the data on the graph
void MainWindow::clearPlots()
{
    qv_x1.clear();          //Clear the x data for plot 1
    qv_y1.clear();          //Clear the y data for plot 1
    qv_x2.clear();          //Clear the x data for plot 2
    qv_y2.clear();          //Clear the y data for plot 2
    ui->plot->xAxis->setRange(0,10.0,Qt::AlignLeft); //Realign the plot
    ui->plot2->xAxis->setRange(0,10.0,Qt::AlignLeft); //Realign the plot
    plot(5);                //Plot the cleared graphs
    existingData = false;   //Mark that there is no recorded data

}

//This function updates the three LCDs on the UI
void MainWindow::updateLCD(const QString value1,const QString value2,const QString value3,const QString value4,const QString value5)
{
    ui->lcdNumber_S1->display(value1);
    ui->lcdNumber_S2->display(value2);
    ui->lcdNumber_T1->display(value3);
    ui->lcdNumber_T2->display(value4);
    ui->lcdNumber_counter->display(value5);

}


// ----------------------------------------------------------------------------------
// SERIAL CONNECTION
// ----------------------------------------------------------------------------------

//This function checks the connection to the Arduino
void MainWindow::checkConnection()
{
    if(!troubleshootingOpen)
    {
        checkPorts();

        if (arduino_is_available)
        {
            disconnectMessageShown = false;
        }

        //If the arduino is not available (disconnected), warn the user
        if (!arduino_is_available || !arduinoConnected)
        {
            if(recording)   //If it is recording, stop recording
            {
                on_btn_record_clicked();    //Stop recording
            }

            if(!newConnection && !disconnectMessageShown && !arduino_is_available)  //If the disconnect message has not been shown, show it
            {
                QMessageBox::critical(this,"Device Disconnected","The device was disconnected. Please reconnect it and complete the setup.");
                disconnectMessageShown = true;
            }
            dataAvailable = false;              //Mark that data is not available
            normalModeVerified = false;         //Mark that the device mode is not verified
            troubleshootMode = false;
            checkPorts();
            connectDevice();
        }
    }
}

//This function checks all the serial ports for the Arduino
void MainWindow::checkPorts()
{
    arduino_is_available = false;

    // Identify the serial port with the Arduino Uno
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        if(serialPortInfo.hasVendorIdentifier() && serialPortInfo.hasProductIdentifier())
        {
            if(serialPortInfo.vendorIdentifier() == arduino_uno_vendor_id)
            {
                if(serialPortInfo.productIdentifier() == arduino_uno_product_id)
                {
                    arduino_port_name = serialPortInfo.portName();
                    arduino_is_available = true;
                }
            }
        }
    }
}

//This function attempts to connect to the Arduino
void MainWindow::connectDevice()
{
    if(arduino->isOpen())
    {
        arduino->close();
    }

    if(arduino_is_available)
    {
        //Open and configure the port
        arduino->setPortName(arduino_port_name);
        arduino->open(QSerialPort::ReadWrite);
        arduino->setBaudRate(QSerialPort::Baud9600); //Change later to match arduino
        arduino->setDataBits(QSerialPort::Data8); //Size of a byte
        arduino->setParity(QSerialPort::NoParity);
        arduino->setStopBits(QSerialPort::OneStop); //may need to change to one and half
        arduino->setFlowControl(QSerialPort::NoFlowControl);
        QObject::connect(arduino,SIGNAL(readyRead()),this, SLOT(readSerial()));
    }

    if(arduino->isOpen())
    {
        arduinoConnected = true;
        newConnection = false;
    }
    else
    {
        arduinoConnected = false;
    }
}

//This function displays a message that the Arduino is missing
void MainWindow::arduinoMissing()
{
    QMessageBox::critical(this,"Port Error","Device not found. Check that the device is connected and setup is complete.");
}


// ----------------------------------------------------------------------------------
// OTHER FUNCTIONS
// ----------------------------------------------------------------------------------

//This function returns the current time, relative to the start time
double MainWindow::getCurrentTime()
{
    if(newTimer)
    {
        newTimer = false;
        startTime.start();
    }
        double timeElapsed = startTime.elapsed()/1000.0;
        return timeElapsed;
}

//This function properly rounds a double to an int
int MainWindow::double2int(double value)
{
    double fraction = value - qFloor(value);
    if(fraction < 0.5)
    {
        return qFloor(value);
    }
    else
    {
        return qCeil(value);
    }
}

//This function calculates log base b of x
double MainWindow::log_b(double b, double x)
{
    return qLn(x)/qLn(b);
}

//This function clears the data
void MainWindow::clearData()
{
    plotWidth = 10;
    ui->slider->setValue(slideMax/2);
    scrollMax = 0;
    ui->scrollBar->setMaximum(scrollMax);   //Disable the scrollBar
    timecode.clear();       //Clear the timecode
    timecodeStr.clear();    //Clear the timecode data
    newTimer = true;        //Reset the timer
    sensor1.clear();        //Clear the sensor 1 data
    sensor2.clear();        //Clear the sensor 2 data
    threshold1.clear();     //Clear threshold 1
    threshold2.clear();     //Clear threshold 2
    counter.clear();        //Clear the counter
    clearPlots();           //Clear the data from the plots
    updateLCD("0","0","0","0","0");       //Zero the number displays
}
