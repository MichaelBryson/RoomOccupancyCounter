#ifndef SENSORDEBUG_H
#define SENSORDEBUG_H

#include <QDialog>
#include <QSerialPort>

namespace Ui {
class sensorDebug;
}

class sensorDebug : public QDialog
{
    Q_OBJECT

public:

    explicit sensorDebug(QWidget *parent = nullptr);
    ~sensorDebug();

    //Key Press Events (Shortcuts)
    void keyPressEvent(QKeyEvent *event);

    //Displays
    void updateLCDdebug(const QString value1, const QString value2, const QString value3, const QString value4, const QString value5, const QString value6);

    //Serial Connection
    void checkPorts();
    void connectDevice();
    void arduinoMissing();

public slots:

    void introMessage();
    void checkConnection();

private slots:

    void readSerialDebug();
    void on_btn_start_clicked();

private:

    Ui::sensorDebug *ui;

    //Serial Setup
    QSerialPort *arduino;
    static const quint16 arduino_uno_vendor_id = 9025;
    static const quint16 arduino_uno_product_id = 67;
    QString arduino_port_name;

    //Serial Connection
    bool arduino_is_available;
    bool arduinoConnected = false;          //Is the serial port configured for the arduino?
    bool disconnectMessageShown = false;
    bool newConnection = true;              //Used to give a warning about unplugging serial device
    QTimer *timer;                          //Timer to check if arduino is still connected during recording

    //Serial Buffer
    QByteArray serialData;
    QString serialBuffer;
    bool dataAvailable = false;             //Used to check if data has been received

    //Troubleshooting
    bool troubleshootMode = false;          //Used to specify if the device is in troubleshooting mode
    bool normalModeVerified = false;        //Used to specify once the device has gone into normal mode

    //Recording
    bool recording = false;                 //Used to toggle recording feature
    bool badData = true;                    //Used to ignore the batch of bad data when recording begins

    //Other
    bool startupMessage = true;

};

#endif // SENSORDEBUG_H
