#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QQueue>
#include <QElapsedTimer>
#include <QTimer>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    //Key Press Events (Shortcuts)
    void keyPressEvent(QKeyEvent *event);

    //Scroll Directions
    void scrollLeft();
    void scrollRight();

    //Plotting and Displays
    void addPoints(double x1, double y1, double x2, double y2);
    void plot(double centerPoint);
    void clearPlots();
    void updateLCD(const QString value1,const QString value2,const QString value3,const QString value4,const QString value5);

    //Serial Connection
    void checkPorts();
    void connectDevice();
    void arduinoMissing();

    //Other Functions
    double getCurrentTime();
    int double2int(double value);
    double log_b(double b, double x);
    void clearData();

public slots:

    void checkConnection();

private slots:

    //Main Buttons
    void on_btn_record_clicked();
    void on_btn_save_clicked();
    void on_btn_clear_clicked();

    //Slider and Scrollbar
    void on_slider_valueChanged(int value);
    void on_scrollBar_valueChanged(int value);

    //Zoom Buttons
    void on_btn_zoomOUT_clicked();
    void on_btn_zoomIN_clicked();

    //File Menu Buttons
    void on_actionRecord_triggered();
    void on_actionSave_triggered();
    void on_actionClear_triggered();

    //Help Menu Buttons
    void on_actionAbout_triggered();
    void on_actionKeyboard_Shortcuts_List_triggered();
    void on_actionQuick_Start_Guide_triggered();
    void on_actionUser_Manual_triggered();
    void on_actionProject_Report_triggered();
    void on_actionRevision_Notes_triggered();
    void on_actionTroubleshoot_triggered();

    //Serial Data Collection
    void readSerial();



private:

    Ui::MainWindow *ui; //Default declaration for the user interface

    //Serial Setup
    QSerialPort *arduino;
    static const quint16 arduino_uno_vendor_id = 9025;
    static const quint16 arduino_uno_product_id = 67;
    QString arduino_port_name;

    //Serial Connection
    bool arduino_is_available;                  //Is the arduino plugged available to be used?
    bool arduinoConnected = false;              //Is the serial port configured for the arduino?
    bool disconnectMessageShown = false;        //Show a message once when the arduino is disconnected
    bool newConnection = true;                  //Used to know when the device has not yet been plugged in
    QTimer *timer;                              //Timer to check if arduino is still connected

    //Serial Data
    QByteArray serialData;                      //Raw serial data input
    QString serialBuffer;                       //Used to temporarily store incoming serial data
    bool dataAvailable = false;                 //Used to check if data has been received

    //Troubleshooting
    bool normalModeVerified = false;            //Used to check if the device is in troubleshooting mode
    bool troubleshootingOpen = false;           //Used to check if the troubleshooting dialog is open
    bool troubleshootMode = false;              //Used to specify if the device is in troubleshooting mode
    bool troubleshootEnabled = false;           //Enable/disable auto open the troubleshooting tool

    //Data Collection
    bool newTimer = true;                       //Used to setup the timer the first time
    QElapsedTimer startTime;                    //Starting time
    QQueue<double> timecode;                    //A queue for storing the time values
    QVector<double> qv_x1, qv_y1, qv_x2, qv_y2; //The data point to be plotted

    //Saved Data
    QStringList timecodeStr;        //A string list of the times for saving later
    QStringList sensor1;            //A string list of the sensor values for saving later
    QStringList sensor2;            //A string list of the sensor values for saving later
    QStringList threshold1;         //A string list of the sensor 1 threshold
    QStringList threshold2;         //A string list of the sensor 2 threshold
    QStringList counter;            //A string list of the counter values
    bool dataSaved = false;         //Variable to specify if the user has saved the data or not

    //Recording
    bool recording = false;         //Used to toggle recording feature
    bool badData = true;            //Used to ignore the batch of bad data when recording begins
    bool existingData = false;      //Used to specify if data already recorded

    //Data Manipulation (zooming and scrolling)
    double plotWidth = 10;          //Plot width as set by the zoom function
    double pwMultiplier = 0.95;     //Fraction of the plot width that can have data in it when scrolled all the way right
    double alignPoint = plotWidth;  //Time used to align the graph edge or center
    double alignTime;               //Time specified by the scroll bar
    double timeMax = 0;             //The latest time sample in the data
    int slideMax = 200;             //Max value for the zoom slider
    int slideValue = slideMax/2;    //Current value of the zoom slider
    int scrollMin = 0;              //Minimum value of the scroll bar
    int scrollMax = 0;              //Maximum value of the scroll bar
    int scrollMaxPrev;              //Previous scrollMax
    int scrollBarValue;             //Current scroll bar value
    int scrollBarValuePrev;         //Previous scroll bar value
    double scrollBarPosition;       //Fractional position of the scroll bar
    bool scrollEnabled = true;      //Used to tell the scroll bar function when the slider function is calling it

};

#endif // MAINWINDOW_H
