#include "sensordebug.h"
#include "ui_sensordebug.h"
#include "mainwindow.h"
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>
#include <QtWidgets>
#include <QString>
#include <QMessageBox>
#include <QTextStream>
#include <QTimer>

// ----------------------------------------------------------------------------------
// CONSTRUCTOR
// ----------------------------------------------------------------------------------
sensorDebug::sensorDebug(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sensorDebug)
{
    ui->setupUi(this);

    // ----------------------------------------------------------------------------------
    // SETUP THE SERIAL PORT FOR THE ARDUINO UNO
    // ----------------------------------------------------------------------------------
    {
    //Initialize Port Variables
    arduino_is_available = false;
    arduino_port_name = "";
    arduino = new QSerialPort;
    serialBuffer = "";

    // Identify the serial port with the Arduino Uno
    checkPorts();

    //Configure the serial port
    connectDevice();
    }

    // ----------------------------------------------------------------------------------
    // SETUP THE WINDOW
    // ----------------------------------------------------------------------------------
    {
    setWindowTitle("Troubleshoot Sensors"); //Set title for the window
    resize(QDesktopWidget().availableGeometry(this).size() * 0.5);

//    //Remove the context help button
//    Qt::WindowFlags flags = windowFlags();
//    Qt::WindowFlags helpFlag = Qt::WindowContextHelpButtonHint;
//    flags = flags & (~helpFlag);
//    setWindowFlags(flags);

    //ui->verticalLayout->setWhatsThis("This tool allows you to view the live values from the photoresistors (LDRs) that make up the two light sensors.");
    }

    // ----------------------------------------------------------------------------------
    // SETUP THE TIMERS
    // ----------------------------------------------------------------------------------
    {
    //Display a one-time startup message
    QTimer::singleShot(0,this,SLOT(introMessage()));

    //Setup the timer to check if the arduino is still connected (used to stop recording if it is disconnected)
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(checkConnection()));
    timer->start(50);
    }
}

// ----------------------------------------------------------------------------------
// DESTRUCTOR
// ----------------------------------------------------------------------------------
sensorDebug::~sensorDebug()
{
    if(arduino->isOpen())
    {
        arduino->close();
    }
    delete ui;
}

// ----------------------------------------------------------------------------------
// BUTTONS
// ----------------------------------------------------------------------------------

//This function starts and stops data collection
void sensorDebug::on_btn_start_clicked()
{
    //If the program was already recording, reset buttonClicked, change text, & stop recording
    if (recording)
    {
        ui->btn_start->setText("Start");
        recording = false;
        badData = true;

    }
    else //If the program was not recording, set buttonClicked, change text, & start recording
    {
        if(arduino->isOpen())
        {
            arduino->close();
        }

        checkPorts();
        connectDevice();

        if(arduino_is_available)
        {
            if(normalModeVerified || troubleshootMode)
            {
                qDebug() << "normalModeVerified = " << normalModeVerified;
                qDebug() << "troubleshootMode = " << troubleshootMode;
                ui->btn_start->setText("Stop");
                recording = true;
            }
            else
            {
                QMessageBox::warning(this,"Setup Incomplete","Please complete the device setup or enter troubleshooting mode.");
            }
        }
        else
        {
            arduinoMissing();
        }
    }
}

//This function handles any key presses for the purpose of shortcuts
void sensorDebug::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_R)
    {
        on_btn_start_clicked();
    }
    else if(event->key() == Qt::Key_Space)
    {
        on_btn_start_clicked();
    }

}



// ----------------------------------------------------------------------------------
// SERIAL DATA COLLECTION
// ----------------------------------------------------------------------------------

//This function collects the serial data from the arduino and displays the data
void sensorDebug::readSerialDebug()
{
    if(!normalModeVerified)
    {
        //Collect Data
        QStringList bufferSplit1 = serialBuffer.split("\n"); //Split the data from the "junk" string
        if(bufferSplit1.length() < 3)
        {
            //Read data from the Arduino and store it in the serialBuffer
            serialData = arduino->readAll();                                    //Read Serial Data
            serialBuffer += QString::fromStdString(serialData.toStdString());   //Store Serial Data
        }
        else
        {
            //Ignore the first set of values that are read from the Arduino
            //Mark that badData is now false and reset the serialBuffer
            if(badData)
            {
                badData = false;
                serialBuffer = "";
            }

            else
            {
                //Extract the sensor data from the string
                //Extract the sensor data from the string
                QStringList bufferSplit2 = bufferSplit1[1].split(","); //Split the values from the two sensors
                QString strNum1 = bufferSplit2[0]; //Extract the value from sensor 1
                QString strNum2 = bufferSplit2[1]; //Extract the value from sensor 2
                QString strNum4 = bufferSplit2[4]; //Extract the counter value
                QString strNum6 = bufferSplit2[5]; //Extract the value from LDR 1a
                QString strNum7 = bufferSplit2[6]; //Extract the value from LDR 1b
                QString strNum8 = bufferSplit2[7]; //Extract the value from LDR 2a
                QString strNum9 = bufferSplit2[8]; //Extract the value from LDR 2b

                int activationCode = strNum4.toInt();
                serialBuffer = ""; //Reset the serialBuffer

                //qDebug() << "Num from Arduino" << num;

                //Evaluate device mode
                //----------------------

                //Normal Device Mode
                if(activationCode >= 0)
                {
                    normalModeVerified = true;
                }

                //Troubleshooting Device Mode
                else
                {
                    //The device is currently sending troubleshoot data
                    if(activationCode == -2)
                    {
                        troubleshootMode = true;                //Enable troubleshoot mode
                        if(recording)
                        {
                            //Update the displays
                            updateLCDdebug(strNum1,strNum2,strNum6,strNum7,strNum8,strNum9);
                        }

                    }
                    //The device has finished sending troubleshoot data
                    else if(activationCode == -3)
                    {
                        troubleshootMode = false;        //End troubleshooting mode
                        if(recording)
                        {
                            on_btn_start_clicked();             //Stop recording
                            QMessageBox::information(this,"Troubleshooting Ended","The device has exited troubleshooting mode.");
                        }
                        badData = true;
                    }
                }
            }
        }
    }
    else
    {
        dataAvailable = true;     //Used to check if data has been received
        //qDebug() << "serial data is available";
        if(recording) //If the record button has been pressed, read values from the Arduino
        {
            QStringList bufferSplit1 = serialBuffer.split("\n"); //Split the data from the "junk" string
            //qDebug() << bufferSplit1;
            if(bufferSplit1.length() < 3)
            {
                //Read data from the Arduino and store it in the serialBuffer
                serialData = arduino->readAll();
                serialBuffer += QString::fromStdString(serialData.toStdString());
            }
            else
            {
                //Ignore the first set of values that are read from the Arduino
                //Mark that badData is now false and reset the serialBuffer
                if(badData)
                {
                    badData = false;
                    serialBuffer = "";
                }

                else
                {
                    //Extract the sensor data from the string
                    QStringList bufferSplit2 = bufferSplit1[1].split(","); //Split the values from the two sensors
                    QString strNum1 = bufferSplit2[0]; //Extract the value from sensor 1
                    QString strNum2 = bufferSplit2[1]; //Extract the value from sensor 2
                    QString strNum6 = bufferSplit2[5]; //Extract the value from LDR 1a
                    QString strNum7 = bufferSplit2[6]; //Extract the value from LDR 1b
                    QString strNum8 = bufferSplit2[7]; //Extract the value from LDR 2a
                    QString strNum9 = bufferSplit2[8]; //Extract the value from LDR 2b

                    //Update the displays
                    updateLCDdebug(strNum1,strNum2,strNum6,strNum7,strNum8,strNum9);
                    serialBuffer = ""; //Reset the serialBuffer
                }
            }
        }
    }
}


// ----------------------------------------------------------------------------------
// DISPLAYS
// ----------------------------------------------------------------------------------

//This function updates the LCDs on the GUI
void sensorDebug::updateLCDdebug(const QString value1,const QString value2,const QString value3,const QString value4,const QString value5,const QString value6)
{
    ui->lcdNumber_1->display(value1);
    ui->lcdNumber_2->display(value2);
    ui->lcdNumber_1a->display(value3);
    ui->lcdNumber_1b->display(value4);
    ui->lcdNumber_2a->display(value5);
    ui->lcdNumber_2b->display(value6);
}


// ----------------------------------------------------------------------------------
// SERIAL CONNECTION
// ----------------------------------------------------------------------------------

//This function checks the connection to the Arduino and stops recording if necessary
void sensorDebug::checkConnection()
{
    checkPorts();

    if (arduino_is_available)
    {
        newConnection = false;
        disconnectMessageShown = false;
    }

    //If the arduino is not available (disconnected), warn the user
    if (!arduino_is_available || !arduinoConnected)
    {
        if(recording)   //If it is recording, stop recording
        {
            on_btn_start_clicked();    //Stop recording
        }

        if(!newConnection && !disconnectMessageShown && !arduino_is_available)  //If the disconnect message has not been shown, show it
        {
            QMessageBox::critical(this,"Device Disconnected","The device was disconnected. Please reconnect it and complete the setup.");
            disconnectMessageShown = true;
            troubleshootMode = false;
        }
        dataAvailable = false;          //Mark that data is not available
        normalModeVerified = false;     //Mark that the device mode is not verified
        checkPorts();
        connectDevice();
    }
}

//This function checks all the serial pors for the Arduino
void sensorDebug::checkPorts()
{
    arduino_is_available = false;

    // Identify the serial port with the Arduino Uno
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        if(serialPortInfo.hasVendorIdentifier() && serialPortInfo.hasProductIdentifier())
        {
            if(serialPortInfo.vendorIdentifier() == arduino_uno_vendor_id)
            {
                if(serialPortInfo.productIdentifier() == arduino_uno_product_id)
                {
                    arduino_port_name = serialPortInfo.portName();
                    arduino_is_available = true;
                }
            }
        }
    }
}

//This function attempts to connect to the Arduino
void sensorDebug::connectDevice()
{
    if(arduino->isOpen())
    {
        arduino->close();
    }

    if(arduino_is_available)
    {
        //Open and configure the port
        arduino->setPortName(arduino_port_name);
        arduino->open(QSerialPort::ReadWrite);
        arduino->setBaudRate(QSerialPort::Baud9600); //Change later to match arduino
        arduino->setDataBits(QSerialPort::Data8); //Size of a byte
        arduino->setParity(QSerialPort::NoParity);
        arduino->setStopBits(QSerialPort::OneStop); //may need to change to one and half
        arduino->setFlowControl(QSerialPort::NoFlowControl);
        QObject::connect(arduino,SIGNAL(readyRead()),this, SLOT(readSerialDebug()));
    }

    if(arduino->isOpen())
    {
        //qDebug() << "Arduino is connected";
        arduinoConnected = true;
        newConnection = false;
    }
    else
    {
        //qDebug() << "Arduino is not connected";
        arduinoConnected = false;
    }
}

//This function displays a message that the arduino is missing
void sensorDebug::arduinoMissing()
{
    QMessageBox::critical(this,"Port Error","Device not found. Check that the device is connected and setup is complete.");
}


// ----------------------------------------------------------------------------------
// OTHER FUNCTIONS
// ----------------------------------------------------------------------------------

//This function displays an information box to tell the user what the tool does
void sensorDebug::introMessage()
{
    QMessageBox::information(this,"Information","This tool allows you to view the live values<br>from the light dependent resistors (LDRs)<br>that make up the light sensors.");
}
